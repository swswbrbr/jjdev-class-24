package service;

public class Item {
	private String dataTime;
	private String stationName;
	private String so2Value;
	private String coValue;
	private String o3Value;
	private String pm10Value;
	private String pm25Value;
	
	public String getDataTime() {
		return dataTime;
	}
	public void setDataTime(String dataTime) {
		this.dataTime = dataTime;
	}
	public String getStationName() {
		return stationName;
	}
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}
	public String getSo2Value() {
		return so2Value;
	}
	public void setSo2Value(String so2Value) {
		this.so2Value = so2Value;
	}
	public String getCoValue() {
		return coValue;
	}
	public void setCoValue(String coValue) {
		this.coValue = coValue;
	}
	public String getO3Value() {
		return o3Value;
	}
	public void setO3Value(String o3Value) {
		this.o3Value = o3Value;
	}
	public String getPm10Value() {
		return pm10Value;
	}
	public void setPm10Value(String pm10Value) {
		this.pm10Value = pm10Value;
	}
	public String getPm25Value() {
		return pm25Value;
	}
	public void setPm25Value(String pm25Value) {
		this.pm25Value = pm25Value;
	}
	
	
	
	
}
