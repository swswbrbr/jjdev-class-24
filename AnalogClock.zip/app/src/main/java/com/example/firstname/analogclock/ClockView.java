package com.example.firstname.analogclock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.icu.util.Calendar;
import android.os.Handler;
import android.os.Message;
import android.view.View;

/**
 * Created by Administrator on 2017-06-22.
 */

public class ClockView extends View {
    int centerW;
    int centerH;
    Bitmap clock;
    Bitmap[] pin = new Bitmap[3];

    // 시계와 바늘의 크기
    int cw, pw, ph;

    // 시, 분, 초, 밀리초
    int hour, min, sec, msec, amPm;

    // 시계 바늘의 회전각도
    float rHour, rMin, rSec;

    public ClockView(Context context) {
        super(context);
        clock = BitmapFactory.decodeResource(getResources(), R.drawable.clock);
        for (int i = 0; i < 3; i++)
            pin[i] = BitmapFactory.decodeResource(getResources(), R.drawable.pin_1 + i);

        // 시계와 바늘의 크기
        cw = clock.getWidth() / 2;
        pw = pin[0].getWidth() / 2;
        ph = pin[0].getHeight() - 60;

        // Handler 호출
        mHandler.sendEmptyMessageDelayed(0, 100);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.scale(0.9f, 0.9f, centerW, centerH);

        canvas.save();

        // 문자판
        canvas.drawBitmap(clock, centerW - cw, centerH - cw, null);

        // 시침
        canvas.rotate(rHour, centerW, centerH);
        canvas.drawBitmap(pin[2], centerW - pw, centerH - ph, null);

        // 분침
        canvas.rotate(rMin - rHour, centerW, centerH);
        canvas.drawBitmap(pin[1], centerW - pw, centerH - ph, null);

        // 초침
        canvas.rotate(rSec - rMin, centerW, centerH);
        canvas.drawBitmap(pin[0], centerW - pw, centerH - ph, null);
        canvas.restore();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerW = w/2;
        centerH = h/2;
    }

    private void getTime(){
        Calendar calendar = Calendar.getInstance();
        hour = calendar.get(calendar.HOUR);
        min = calendar.get(calendar.MINUTE);
        sec = calendar.get(calendar.SECOND);
        msec = calendar.get(calendar.MILLISECOND)/100;

        // 시계 바늘 각도 계산
        rSec = sec * 6;
        rMin = min * 6 + rSec / 60;
        rHour = hour * 30 + rMin / 12;
    }

    // Handler
    Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            getTime();
            invalidate();
            mHandler.sendEmptyMessageDelayed(0, 100);
        }
    };
}
