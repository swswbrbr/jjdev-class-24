package com.pineapple.funding.Board;

public class ChartDTO {
	private int taskId;
	private String taskName;
	private String resource;
	private String startDate;
	private String endDate;
	private int duration;
	private int percentComplete;
	private String dependencies;
	
	
	public int getTaskId() {
		return taskId;
	}


	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}


	public String getTaskName() {
		return taskName;
	}


	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}


	public String getResource() {
		return resource;
	}


	public void setResource(String resource) {
		this.resource = resource;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	public int getPercentComplete() {
		return percentComplete;
	}


	public void setPercentComplete(int percentComplete) {
		this.percentComplete = percentComplete;
	}


	public String getDependencies() {
		return dependencies;
	}


	public void setDependencies(String dependencies) {
		this.dependencies = dependencies;
	}


	@Override
	public String toString() {
		return "ChartDTO [taskId=" + taskId + ", taskName=" + taskName + ", resource=" + resource + ", startDate="
				+ startDate + ", endDate=" + endDate + ", duration=" + duration + ", percentComplete=" + percentComplete
				+ ", dependencies=" + dependencies + "]";
	}
	
}
