package com.pineapple.funding.Board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {
@Autowired
BoardDAO boarddao;
	
	public ChartDTO getChartList(int chartNo){
		System.out.println("BoardService�� getChartList �޼��� ȣ�� ����");
		return boarddao.selectChartList(chartNo);
	}
}
