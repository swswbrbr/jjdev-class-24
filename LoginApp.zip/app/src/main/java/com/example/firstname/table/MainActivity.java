package com.example.firstname.table;

import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText idEdit;
    private  EditText pwEdit;
    private Button loginBtn;
    private  final String SYSTEM_ID = "jjdev";
    private  final String SYSTEM_PW = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idEdit = (EditText)findViewById(R.id.id_edit);
        pwEdit = (EditText)findViewById(R.id.pw_edit);
        loginBtn = (Button)findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view) {
                String id = idEdit.getText().toString();
                String pw = pwEdit.getText().toString();

                if(id.length()<4 || pw.length()<4){
                    Toast.makeText(MainActivity.this, "4자이상....", Toast.LENGTH_SHORT).show();
                }else {
                    if(id.equals(SYSTEM_ID) && pw.equals(SYSTEM_PW)){
                        Toast.makeText(MainActivity.this, "로그인 성공", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
