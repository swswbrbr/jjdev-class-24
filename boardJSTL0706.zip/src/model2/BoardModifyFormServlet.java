package model2;
 
import java.io.IOException;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/model2_board/BoardModifyFormServlet.do")
public class BoardModifyFormServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ��ûó��
        if(request.getParameter("boardNo") == null) {
            response.sendRedirect(request.getContextPath()+"/model2_board/BoardListServlet.do");
        } else {
            int boardNo = Integer.parseInt(request.getParameter("boardNo"));
            //System.out.println("boardModify param boardNo:"+boardNo);
            
         // dao ȣ��(getBoard()ȣ��)    
            BoardDao boardDao = new BoardDao();
            Board board = boardDao.getBoard(boardNo);
            request.setAttribute("board", board);
        // 1. �䰡 ������ ��� ������
        // 2. �䰡 ������ �ٸ� ��û�� �����̷�Ʈ
        // ���⼭�� ��(boardModifyForm.jsp)�� �ִ�
            RequestDispatcher rd = request.getRequestDispatcher("/model2_board/boardModifyForm.jsp");
            rd.forward(request, response);
        }
    }
}

