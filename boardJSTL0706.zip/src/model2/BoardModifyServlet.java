package model2;
 
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/model2_board/BoardModifyServlet.do")
public class BoardModifyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("euc-kr");
        if(request.getParameter("boardNo") == null || request.getParameter("boardPw") == null) {
            response.sendRedirect(request.getContextPath()+"/model2_board/BoardListServlet.do");
        } else {
            int boardNo = Integer.parseInt(request.getParameter("boardNo"));
            //System.out.println("param boardNo :"+boardNo);
            String boardPw = request.getParameter("boardPw");
            //System.out.println("param boardPw :"+boardPw);
            String boardTitle = request.getParameter("boardTitle");
            //System.out.println("param boardTitle :"+boardTitle);
            String boardContent = request.getParameter("boardContent");
            //System.out.println("param boardContent :"+boardContent);
            
            // ��û������ �̿��Ͽ� �Ű������� ������ �� Board��ü����
            Board board = new Board();
            board.setBoardNo(boardNo);
            board.setBoardPw(boardPw);
            board.setBoardTitle(boardTitle);
            board.setBoardContent(boardContent);
            BoardDao boardDao = new BoardDao();
            boardDao.updateBoard(board);
            response.sendRedirect(request.getContextPath()+"/model2_board/BoardViewServlet.do?boardNo="+boardNo);
        }    
    }
}


