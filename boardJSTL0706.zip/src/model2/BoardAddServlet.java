package model2;
 
import java.io.IOException;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
 
@WebServlet("/model2_board/BoardAddServlet.do")
public class BoardAddServlet extends HttpServlet {
	private BoardDao boardDao;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ��ûó��
        request.setCharacterEncoding("euc-kr");
        String boardPw = request.getParameter("boardPw");
        //System.out.println("param boardPw:"+boardPw);
        String boardTitle = request.getParameter("boardTitle");
        //System.out.println("param boardTitle:"+boardTitle);
        String boardContent = request.getParameter("boardContent");
        //System.out.println("param boardContent:"+boardContent);
        String boardUser = request.getParameter("boardUser");
        //System.out.println("param boardUser:"+boardUser);
        Board board = new Board(); 
        board.setBoardPw(boardPw);
        board.setBoardTitle(boardTitle);
        board.setBoardContent(boardContent);
        board.setBoardUser(boardUser);
        
        // daoȣ��
        boardDao = new BoardDao();
        int row = boardDao.insertBoard(board); // row�� 1�̸� �Է¼���, �ƴϸ� �Է½���
        System.out.println("row : "+row);
        
        // �ٸ���û���� �����̷�Ʈ
        // /model2_board/BoardListServlet�� ���� ������ �ʾ����Ƿ� �������� 404������ �߻��Ѵ�. 
        response.sendRedirect(request.getContextPath()+"/model2_board/BoardListServlet.do");
    }
}

