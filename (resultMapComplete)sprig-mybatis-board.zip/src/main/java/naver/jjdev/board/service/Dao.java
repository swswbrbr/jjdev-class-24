package naver.jjdev.board.service;

import java.util.List;

public interface Dao {

	int updateBoard(Board board);

	int deleteBoard(int boardNo, String boardPw);

	Board getBoard(int boardNo);

	List<Board> getBoardList(int currentPage, int pagePerRow);

	int getBoardCount();

	int insertBoard(Board board);
	
	Member getMemberBoardList(int memberNo);

}