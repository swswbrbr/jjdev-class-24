package naver.jjdev.board.service;

import java.util.List;

public class Member {
	private int memberNo;
	private String memberName;
	private String memberAddr;
	private List<Board> boardList; //1:n 관계 -> mampper에서 순서대로 resultMap 셋팅 할 수 있음.
	
	public int getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(int memberNo) {
		this.memberNo = memberNo;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getMemberAddr() {
		return memberAddr;
	}
	public void setMemberAddr(String memberAddr) {
		this.memberAddr = memberAddr;
	}
	public List<Board> getBoards() {
		return boardList;
	}
	public void setBoards(List<Board> boards) {
		this.boardList = boards;
	}
	
	@Override
	public String toString() {
		return "Member [memberNo=" + memberNo + ", memberName=" + memberName + ", memberAddr=" + memberAddr
				+ ", boards=" + boardList + "]";
	}
	
	
	
}
