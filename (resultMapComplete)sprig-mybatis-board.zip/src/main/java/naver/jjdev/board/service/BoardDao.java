package naver.jjdev.board.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
 
@Repository
public class BoardDao implements Dao { 
    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;
    
    /* (non-Javadoc)
	 * @see naver.jjdev.board.service.Dao#updateBoard(naver.jjdev.board.service.Board)
	 */
    @Override
	public int updateBoard(Board board) {
        return sqlSessionTemplate.update("naver.jjdev.board.service.BoardMapper.updateBoard", board);
    }
    
    /* (non-Javadoc)
	 * @see naver.jjdev.board.service.Dao#deleteBoard(int, java.lang.String)
	 */
    @Override
	public int deleteBoard(int boardNo, String boardPw) {
        Board board = new Board();
        board.setBoardNo(boardNo);
        board.setBoardPw(boardPw);
        return sqlSessionTemplate.delete("naver.jjdev.board.service.BoardMapper.deleteBoard", board);
    }
    
    /* (non-Javadoc)
	 * @see naver.jjdev.board.service.Dao#getBoard(int)
	 */
    @Override
	public Board getBoard(int boardNo) {
        return sqlSessionTemplate.selectOne("naver.jjdev.board.service.BoardMapper.getBoard", boardNo);
    }
 
    /* (non-Javadoc)
	 * @see naver.jjdev.board.service.Dao#getBoardList(int, int)
	 */
    @Override
	public List<Board> getBoardList(int currentPage, int pagePerRow) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("beginRow", (currentPage-1)*pagePerRow);
        map.put("pagePerRow", pagePerRow);
        return sqlSessionTemplate.selectList("naver.jjdev.board.service.BoardMapper.getBoardList", map);
    }
    
    /* (non-Javadoc)
	 * @see naver.jjdev.board.service.Dao#getBoardCount()
	 */
    @Override
	public int getBoardCount() {
        return sqlSessionTemplate.selectOne("naver.jjdev.board.service.BoardMapper.getBoardCount");
    }
 
    /* (non-Javadoc)
	 * @see naver.jjdev.board.service.Dao#insertBoard(naver.jjdev.board.service.Board)
	 */
    @Override
	public int insertBoard(Board board) {
    	int row = sqlSessionTemplate.insert("naver.jjdev.board.service.BoardMapper.insertBoard", board);
    	int pk = board.getBoardNo();
    	System.out.println("입력된 pk값 : "+pk);
        return row;
    }

	@Override
	public Member getMemberBoardList(int memberNo) {
		Member member = new Member();
		member.setMemberNo(memberNo);
		return sqlSessionTemplate.selectOne("naver.jjdev.board.service.MemberMapper.getMemberAndBoardList", member);
	}
    
}

