package naver.jjdev.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

@org.springframework.stereotype.Service

public class BoardService implements Service {
	@Autowired
	private Dao dao;
	
	@Override
	public int modifyBoard(Board board) {
		//controller에게서 넘겨받은 파라미터 가공
		//Board board = dao.updateBoard(board);
		//transaction 처리
		//dao 호출 후 리턴값을 가공
		return dao.updateBoard(board);
	}

	@Override
	public int removeBoard(int boardNo, String boardPw) {
		//boardNo와 boardPw 하나의 (Map)타입으로 묶어...
		//Map map = new HashMap<String, Object>();
		return dao.deleteBoard(boardNo, boardPw);
	}

	@Override
	public Board selectBoard(int boardNo) {
		// TODO Auto-generated method stub
		return dao.getBoard(boardNo);
	}

	@Override
	public List<Board> selectBoardList(int currentPage, int pagePerRow) {
		// TODO Auto-generated method stub
		return dao.getBoardList(currentPage, pagePerRow);
	}

	@Override
	public int selectBoardCount() {
		// TODO Auto-generated method stub
		return dao.getBoardCount();
	}

	@Override
	public int addBoard(Board board) {
		// TODO Auto-generated method stub
		return dao.insertBoard(board);
	}

	@Override
	public Member selectMemberBoardLlist(int memberNo) {
		// TODO Auto-generated method stub
		return dao.getMemberBoardList(memberNo);
	}
	
}
