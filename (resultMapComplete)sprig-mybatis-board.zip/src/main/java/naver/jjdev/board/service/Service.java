package naver.jjdev.board.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
@Transactional
public interface Service {
	
	int modifyBoard(Board board);

	int removeBoard(int boardNo, String boardPw);

	Board selectBoard(int boardNo);

	List<Board> selectBoardList(int currentPage, int pagePerRow);

	int selectBoardCount();

	int addBoard(Board board);
	

	Member selectMemberBoardLlist(int memberNo);

}
