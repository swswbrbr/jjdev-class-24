package naver.jjdev.board.service;

//1:1 관계 모델
public class BoardAndMember {
	private Board board;
	private Member member;
	
	public Board getBoard() {
		return board;
	}
	public void setBoard(Board board) {
		this.board = board;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	
	@Override
	public String toString() {
		return "BoardAndMember [board=" + board + ", member=" + member + "]";
	}
}
