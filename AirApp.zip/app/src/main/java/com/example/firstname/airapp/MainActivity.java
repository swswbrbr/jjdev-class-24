package com.example.firstname.airapp;

import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    BarChart barChart;
    ArrayList<String> labels;
    ArrayList<BarEntry> entries;
    String dataTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        barChart = (BarChart)findViewById(R.id.barChart);
        new TmpThread().execute();
    }

    class TmpThread extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            Map<String, String> map = AirService.getAir();
            Log.d("air", "doInBackground ; "+ map);
            return map;
        }

        @Override
        protected void onPostExecute(Object o) {
            Map<String, String> map = (Map<String, String>)o;
            StringBuffer sb = new StringBuffer();
            for (String keyName : map.keySet()){
                sb.append(keyName+" : "+map.get(keyName)+"\n");
            }
            Log.d("air", sb.toString());
            dataTime = map.get("dataTime");
            map.remove("dataTime");
            labels = new ArrayList<String>();//x축
            entries = new ArrayList<BarEntry>();//y축
            int index = 0;
            for(String keyName : map.keySet()){
                labels.add(keyName);
                entries.add(new BarEntry(index++, Float.parseFloat(map.get(keyName))));

            }
            Log.d("labels :", labels.toString());
            Log.d("values :", entries.toString());

            //barChart 모델값 x축, y축, 값 등을 설정...
            BarDataSet barDataSet = new BarDataSet(entries, "KOREA AIR");
            barDataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);
            barDataSet.setDrawValues(true);


            BarData barData = new BarData(barDataSet);
            barChart.setData(barData); // set the data and list of lables into chart
            XAxis xAxis = new XAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));

            barChart.invalidate();

/*
            MarkerView mv = new MarkerView(this, );
            barChart.setMarkerView(mv);
            barChart.setDrawMarkerViews(true);

            YAxis y = barChart.getAxisLeft();
            y.setTextColor(Color.WHITE);

            XAxis x = barChart.getXAxis();
            x.setTextColor(Color.WHITE);

            Legend legend = barChart.getLegend();
            legend.setTextColor(Color.WHITE);
            */
        }
    }
}
