package com.example.firstname.touchapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView resultView;
    private float downX;
    private float upX;
    int resultValue =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultView = (TextView)findViewById(R.id.resultView);
        resultView.setOnTouchListener(new TextView.OnTouchListener(){

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = motionEvent.getX();
                        break;
                    case MotionEvent.ACTION_UP:
                        upX = motionEvent.getX();
                        if (upX < downX - 10) {
                            resultValue = Integer.parseInt(resultView.getText().toString());
                            resultView.setText(--resultValue + "");
                        } else if (upX > downX + 10) {
                            resultView.setText(++resultValue + "");
                        }
                        break;
                }
                return true;
            }
        });

    }
}
