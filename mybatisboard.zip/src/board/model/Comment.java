package board.model;

public class Comment {

}
